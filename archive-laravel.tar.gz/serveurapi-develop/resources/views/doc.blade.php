<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salle API Documentation</title>
</head>
<body>
<div id="rapidoc"></div>
<rapi-doc spec-url="{{asset('/openapi/openapi.yaml') }}"
show-method-in-nav-bar="as-colored-block"
show-header="false"></rapi-doc>
<script type="module" src="https://unpkg.com/rapidoc/dist/rapidoc-min.js"></script>
</body>
</html>
